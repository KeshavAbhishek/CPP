#include <iostream>
using namespace std;

int main() {
    int intValue = 42;
    double doubleValue = 3.14;
    char charValue = 'A';

    void* genericPointer; // Declaring a void pointer

    // Assigning the address of an int variable to the void pointer
    genericPointer = &intValue;

    // To use the value pointed to by the void pointer, you need to cast it back to the appropriate type
    int* intPointer = (int *)genericPointer;
    cout << "Value through int pointer: " << *intPointer << endl;

    // Assigning the address of a double variable to the void pointer
    genericPointer = &doubleValue;

    // Casting back to the double type to access the value
    double* doublePointer = (double *)genericPointer;
    cout << "Value through double pointer: " << *doublePointer << endl;

    // Assigning the address of a char variable to the void pointer
    genericPointer = &charValue;

    // Casting back to the char type to access the value
    char* charPointer = (char *)genericPointer;
    cout << "Value through char pointer: " << *charPointer << endl;

    return 0;
}